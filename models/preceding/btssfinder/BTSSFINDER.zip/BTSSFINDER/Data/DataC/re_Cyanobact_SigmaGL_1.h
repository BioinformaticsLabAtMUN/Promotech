FREQs of    11 RE motifs in [  1:251], (+ chain) of "Pos" SEQs |Similarity: >= 80%; Found in >=  5.00% of "Pos" SEQs and <= 10.00% of "Neg" SEQs; Ratio of "Pos" and "Neg" FREQs:   1.50
11
0.0653
0.0653
0.0568
0.0701
0.0883
0.0859
0.0556
0.0556
0.0834
0.0931
0.0931
//
