Prom251_Cyanobact_SigmaFL.seq: Final -15 box Matrix for    518 Proms (out of    586) ... Distance to -10:   0 -  5 ... Threshold =  -0.5000

0.3629	0.2741	0.2799	0.0000	0.1486	
0.1911	0.3320	0.2606	0.0000	0.2954	
0.1042	0.1544	0.0097	0.7568	0.2297	
0.3417	0.2394	0.4498	0.2432	0.3263	
