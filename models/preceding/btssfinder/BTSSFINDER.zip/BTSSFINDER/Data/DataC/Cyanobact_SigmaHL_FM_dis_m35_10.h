Cyanobact_SigmaHL.seq: Final -35/-10 distance FREQs Matrix for    113 Proms (out of    170)
5	Length of -35/-10 Distance Interval
12	16	MIN and MAX -35/-10 distances

0.1947	
0.1947	
0.1947	
0.2832	
0.1327	
