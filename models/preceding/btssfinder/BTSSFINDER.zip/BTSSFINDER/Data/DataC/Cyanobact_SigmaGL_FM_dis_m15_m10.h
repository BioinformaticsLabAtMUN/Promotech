Prom251_Cyanobact_SigmaGL.seq: Final -15/-10 distance FREQs Matrix for    828 Proms (out of    828)
6	Length of -15/-10 Distance Interval
0	5	MIN and MAX -15/-10 distances

0.2717	
0.1341	
0.1232	
0.1618	
0.1232	
0.1860	
