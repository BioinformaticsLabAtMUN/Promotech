Prom251_Ecoli_Sigma38L.seq: Final -10/TSS distance FREQs Matrix for    100 Proms (out of    100)
10	Length of -10/TSS Distance Interval
3	12	MIN and MAX -10/TSS distances

0.0200	
0.0200	
0.1800	
0.1400	
0.3600	
0.1400	
0.0400	
0.0200	
0.0500	
0.0300	
