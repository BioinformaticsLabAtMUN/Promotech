Prom251_Cyanobact_SigmaGL.seq: Final -10/TSS distance FREQs Matrix for    828 Proms (out of    828)
7	Length of -10/TSS Distance Interval
6	12	MIN and MAX -10/TSS distances

0.1087	
0.0990	
0.1377	
0.1208	
0.1389	
0.2210	
0.1739	
