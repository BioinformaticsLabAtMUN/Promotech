Prom251_Cyanobact_SigmaAL.seq: Final UP/-35 distance FREQs Matrix for   7919 Proms (out of   7920)

  0.0158              0
  0.0943     >   0 and <=  10
  0.0849     >  10 and <=  20
  0.0779     >  20 and <=  30
  0.0794     >  30 and <=  40
  0.0737     >  40 and <=  50
  0.0703     >  50 and <=  60
  0.0686     >  60 and <=  70
  0.0751     >  70 and <=  80
  0.0744     >  80 and <=  90
  0.0630     >  90 and <= 100
  0.2225          > 100

Min UP/-35 distance:   0
Max UP/-35 distance: 130
