Prom251_Cyanobact_SigmaAL.seq: Final -15/-10 distance FREQs Matrix for   8232 Proms (out of   8232)
11	Length of -15/-10 Distance Interval
0	10	MIN and MAX -15/-10 distances

0.2534	
0.0873	
0.1036	
0.0709	
0.0532	
0.0613	
0.0617	
0.0662	
0.0725	
0.0796	
0.0901	
