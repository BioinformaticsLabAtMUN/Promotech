Prom251_Ecoli_Sigma28L.seq: Final -35/-10 distance FREQs Matrix for    100 Proms (out of    100)
3	Length of -35/-10 Distance Interval
10	12	MIN and MAX -35/-10 distances

0.1000	
0.5800	
0.3200	
