Prom251_Ecoli_Sigma32L.seq: Final -35/-10 distance FREQs Matrix for    147 Proms (out of    187)
3	Length of -35/-10 Distance Interval
13	15	MIN and MAX -35/-10 distances

0.3878	
0.2653	
0.3469	
