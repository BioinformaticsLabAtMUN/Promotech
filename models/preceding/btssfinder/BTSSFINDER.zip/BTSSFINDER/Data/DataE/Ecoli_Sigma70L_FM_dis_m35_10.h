Prom251_Ecoli_Sigma70L.seq: Final -35/-10 distance FREQs Matrix for   1326 Proms (out of   1344)
8	Length of -35/-10 Distance Interval
15	22	MIN and MAX -35/-10 distances

0.1267	
0.1554	
0.2172	
0.1199	
0.1071	
0.1078	
0.1131	
0.0528	
