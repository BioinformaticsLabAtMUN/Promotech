Prom251_Cyanobact_SigmaGL.seq: Final -15 box Matrix for    828 Proms (out of    828) ... Distance to -10:   0 -  5 ... Threshold =  -2.0000

0.2705	0.2742	0.1812	0.0918	0.0942	
0.1932	0.2899	0.2379	0.0737	0.2729	
0.1292	0.2053	0.0942	0.6932	0.3792	
0.4070	0.2307	0.4867	0.1413	0.2536	
