Prom251_Ecoli_Sigma28L.seq: Final -15/-10 distance FREQs Matrix for     87 Proms (out of    100)
6	Length of -15/-10 Distance Interval
0	5	MIN and MAX -15/-10 distances

0.2529	
0.1494	
0.1494	
0.1149	
0.1264	
0.2069	
