Prom251_Ecoli_Sigma38L.seq: Final -15/-10 distance FREQs Matrix for     98 Proms (out of    100)
11	Length of -15/-10 Distance Interval
0	10	MIN and MAX -15/-10 distances

0.1939	
0.0918	
0.1122	
0.0816	
0.0714	
0.0714	
0.0510	
0.0408	
0.0918	
0.1020	
0.0918	
