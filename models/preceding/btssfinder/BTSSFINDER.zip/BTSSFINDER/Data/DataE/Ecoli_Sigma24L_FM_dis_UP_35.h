Prom251_Ecoli_Sigma24L.seq: Final UP/-35 distance FREQs Matrix for    298 Proms (out of    298)

  0.0101              0
  0.1141     >   0 and <=  10
  0.0872     >  10 and <=  20
  0.1141     >  20 and <=  30
  0.0537     >  30 and <=  40
  0.0638     >  40 and <=  50
  0.0772     >  50 and <=  60
  0.0839     >  60 and <=  70
  0.0872     >  70 and <=  80
  0.0503     >  80 and <=  90
  0.0671     >  90 and <= 100
  0.1913          > 100

Min UP/-35 distance:   0
Max UP/-35 distance: 130
