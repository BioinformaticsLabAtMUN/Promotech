Prom251_Cyanobact_SigmaFL.seq: Final -15/-10 distance FREQs Matrix for    518 Proms (out of    586)
6	Length of -15/-10 Distance Interval
0	5	MIN and MAX -15/-10 distances

0.2819	
0.1236	
0.1583	
0.1236	
0.1660	
0.1467	
