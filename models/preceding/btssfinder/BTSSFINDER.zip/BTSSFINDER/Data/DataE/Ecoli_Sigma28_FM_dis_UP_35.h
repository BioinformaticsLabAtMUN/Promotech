Prom251_Ecoli_Sigma28L.seq: Final UP/-35 distance FREQs Matrix for    100 Proms (out of    100)

  0.0000              0
  0.0900     >   0 and <=  10
  0.0900     >  10 and <=  20
  0.0900     >  20 and <=  30
  0.0800     >  30 and <=  40
  0.1000     >  40 and <=  50
  0.0600     >  50 and <=  60
  0.0800     >  60 and <=  70
  0.0400     >  70 and <=  80
  0.0700     >  80 and <=  90
  0.1100     >  90 and <= 100
  0.1900          > 100

Min UP/-35 distance:   2
Max UP/-35 distance: 129
