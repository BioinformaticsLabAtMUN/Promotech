Prom251_Ecoli_Sigma24L.seq: Final -35/-10 distance FREQs Matrix for    298 Proms (out of    312)
8	Length of -35/-10 Distance Interval
12	19	MIN and MAX -35/-10 distances

0.0470	
0.0940	
0.0738	
0.1846	
0.1980	
0.1477	
0.0772	
0.1779	
