Cyanobact_SigmaCL.seq: Final -15/-10 distance FREQs Matrix for    295 Proms (out of    304)
11	Length of -15/-10 Distance Interval
0	10	MIN and MAX -15/-10 distances

0.2881	
0.0915	
0.0949	
0.0644	
0.0576	
0.0576	
0.0373	
0.0746	
0.0814	
0.0610	
0.0915	
