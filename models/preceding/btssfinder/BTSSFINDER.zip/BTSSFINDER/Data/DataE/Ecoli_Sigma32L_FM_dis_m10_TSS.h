Prom251_Ecoli_Sigma32L.seq: Final -10/TSS distance FREQs Matrix for    187 Proms (out of    187)
10	Length of -10/TSS Distance Interval
3	12	MIN and MAX -10/TSS distances

0.2246	
0.3583	
0.1337	
0.0214	
0.0214	
0.1176	
0.0588	
0.0374	
0.0214	
0.0053	
