Prom251_Ecoli_Sigma70L.seq: Final UP/-35 distance FREQs Matrix for   1326 Proms (out of   1326)

  0.0151              0
  0.1109     >   0 and <=  10
  0.1011     >  10 and <=  20
  0.0980     >  20 and <=  30
  0.0965     >  30 and <=  40
  0.0633     >  40 and <=  50
  0.0724     >  50 and <=  60
  0.0807     >  60 and <=  70
  0.0664     >  70 and <=  80
  0.0611     >  80 and <=  90
  0.0588     >  90 and <= 100
  0.1757          > 100

Min UP/-35 distance:   0
Max UP/-35 distance: 130
