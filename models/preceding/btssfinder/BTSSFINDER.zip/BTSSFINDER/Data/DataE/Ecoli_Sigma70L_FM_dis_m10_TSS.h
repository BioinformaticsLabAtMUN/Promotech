Prom251_Ecoli_Sigma70L.seq: Final -10/TSS distance FREQs Matrix for   1344 Proms (out of   1344)
10	Length of -10/TSS Distance Interval
3	12	MIN and MAX -10/TSS distances

0.0216	
0.0320	
0.1912	
0.2790	
0.2351	
0.1101	
0.0588	
0.0208	
0.0312	
0.0201	
