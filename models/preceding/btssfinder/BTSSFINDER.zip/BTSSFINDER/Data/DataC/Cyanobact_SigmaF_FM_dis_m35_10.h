Prom251_Cyanobact_SigmaFL.seq: Final -35/-10 distance FREQs Matrix for    507 Proms (out of    586)
6	Length of -35/-10 Distance Interval
12	17	MIN and MAX -35/-10 distances

0.1854	
0.1677	
0.1834	
0.1420	
0.1479	
0.1736	
