Prom251_Ecoli_Sigma24L.seq: Final -15/-10 distance FREQs Matrix for    291 Proms (out of    312)
11	Length of -15/-10 Distance Interval
0	10	MIN and MAX -15/-10 distances

0.1478	
0.0653	
0.0722	
0.0962	
0.0859	
0.0687	
0.0756	
0.0722	
0.1031	
0.0893	
0.1237	
