FREQs of     5 RE motifs in [  1:200], (+/- chains) of "Pos" SEQs |Similarity: >= 80%; Found in >=  5.00% of "Pos" SEQs and <= 10.00% of "Neg" SEQs; Ratio of "Pos" and "Neg" FREQs:   1.50
5
0.1124
0.0533
0.0947
0.1361
0.1479
//
