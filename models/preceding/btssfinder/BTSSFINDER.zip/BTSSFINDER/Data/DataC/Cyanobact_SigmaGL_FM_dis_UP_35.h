Prom251_Cyanobact_SigmaGL.seq: Final UP/-35 distance FREQs Matrix for    805 Proms (out of    806)

  0.0112              0
  0.1180     >   0 and <=  10
  0.1081     >  10 and <=  20
  0.1031     >  20 and <=  30
  0.0882     >  30 and <=  40
  0.0894     >  40 and <=  50
  0.1118     >  50 and <=  60
  0.0944     >  60 and <=  70
  0.0870     >  70 and <=  80
  0.0919     >  80 and <=  90
  0.0969     >  90 and <= 100
  0.0000          > 100

Min UP/-35 distance:   0
Max UP/-35 distance: 100
