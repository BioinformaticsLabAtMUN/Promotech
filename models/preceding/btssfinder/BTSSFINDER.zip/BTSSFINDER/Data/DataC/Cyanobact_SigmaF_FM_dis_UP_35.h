Prom251_Cyanobact_SigmaFL.seq: Final UP/-35 distance FREQs Matrix for    507 Proms (out of    507)

  0.0118              0
  0.1223     >   0 and <=  10
  0.1085     >  10 and <=  20
  0.0888     >  20 and <=  30
  0.0828     >  30 and <=  40
  0.1262     >  40 and <=  50
  0.0907     >  50 and <=  60
  0.1085     >  60 and <=  70
  0.0888     >  70 and <=  80
  0.0966     >  80 and <=  90
  0.0750     >  90 and <= 100
  0.0000          > 100

Min UP/-35 distance:   0
Max UP/-35 distance: 100
