Cyanobact_SigmaCL.seq: Final -10/TSS distance FREQs Matrix for    304 Proms (out of    305)
10	Length of -10/TSS Distance Interval
3	12	MIN and MAX -10/TSS distances

0.0493	
0.0526	
0.0724	
0.1053	
0.3224	
0.2401	
0.0625	
0.0329	
0.0296	
0.0329	
