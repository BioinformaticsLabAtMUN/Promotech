Prom251_Cyanobact_SigmaGL.seq: Final -35/-10 distance FREQs Matrix for    806 Proms (out of    828)
8	Length of -35/-10 Distance Interval
12	19	MIN and MAX -35/-10 distances

0.1774	
0.1079	
0.0744	
0.1365	
0.1216	
0.1179	
0.1166	
0.1476	
