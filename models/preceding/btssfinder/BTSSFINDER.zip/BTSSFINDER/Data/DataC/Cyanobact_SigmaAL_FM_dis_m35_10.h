Prom251_Cyanobact_SigmaAL.seq: Final -35/-10 distance FREQs Matrix for   7920 Proms (out of   8232)
8	Length of -35/-10 Distance Interval
15	22	MIN and MAX -35/-10 distances

0.1163	
0.1236	
0.1457	
0.1468	
0.1289	
0.1082	
0.1034	
0.1270	
