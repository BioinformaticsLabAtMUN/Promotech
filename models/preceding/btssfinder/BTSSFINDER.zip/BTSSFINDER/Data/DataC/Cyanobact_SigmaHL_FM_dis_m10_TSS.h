Cyanobact_SigmaHL.seq: Final -10/TSS distance FREQs Matrix for    169 Proms (out of    170)
10	Length of -10/TSS Distance Interval
3	12	MIN and MAX -10/TSS distances

0.1361	
0.1183	
0.0888	
0.1420	
0.1124	
0.0828	
0.0828	
0.0710	
0.0769	
0.0888	
