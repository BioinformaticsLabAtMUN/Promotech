Cyanobact_SigmaCL.seq: Final UP/-35 distance FREQs Matrix for    301 Proms (out of    303)

  0.0199              0
  0.1130     >   0 and <=  10
  0.0664     >  10 and <=  20
  0.0432     >  20 and <=  30
  0.0764     >  30 and <=  40
  0.1030     >  40 and <=  50
  0.0731     >  50 and <=  60
  0.0598     >  60 and <=  70
  0.0598     >  70 and <=  80
  0.0631     >  80 and <=  90
  0.0797     >  90 and <= 100
  0.2425          > 100

Min UP/-35 distance:   0
Max UP/-35 distance: 130
