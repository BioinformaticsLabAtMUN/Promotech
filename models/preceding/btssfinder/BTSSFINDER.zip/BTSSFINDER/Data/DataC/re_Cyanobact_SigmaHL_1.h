FREQs of    12 RE motifs in [  1:251], (+ chain) of "Pos" SEQs |Similarity: >= 80%; Found in >=  5.00% of "Pos" SEQs and <= 10.00% of "Neg" SEQs; Ratio of "Pos" and "Neg" FREQs:   1.50
12
0.0592
0.0592
0.0710
0.1361
0.0888
0.1006
0.1065
0.0651
0.0592
0.0592
0.0533
0.0769
//
