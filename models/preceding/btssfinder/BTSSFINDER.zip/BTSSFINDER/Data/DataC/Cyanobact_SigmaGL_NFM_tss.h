Prom251_Cyanobact_SigmaGL.seq: Final TSS core-motif Matrix for    801 Proms (out of    828) ... Search region   195 : 202 ... Threshold =  -7.8100

0.7578	0.2447	0.1386	0.1448	0.2385	0.7291	
0.0687	0.1710	0.3121	0.1561	0.1586	0.0762	
0.0936	0.2060	0.2022	0.2085	0.3246	0.1049	
0.0799	0.3783	0.3471	0.4906	0.2784	0.0899	

Prom251_Cyanobact_SigmaGL.seq: Final TSS extended motif Matrix for    801 Proms (out of    828) ... Search region   195 : 202 ... Threshold =  -7.8100
9	Length of promoter element

0.7578	0.2447	0.1386	0.1448	0.2385	0.7291	0.2010	0.2085	0.2447	
0.0687	0.1710	0.3121	0.1561	0.1586	0.0762	0.2222	0.2472	0.2210	
0.0936	0.2060	0.2022	0.2085	0.3246	0.1049	0.3159	0.2821	0.2921	
0.0799	0.3783	0.3471	0.4906	0.2784	0.0899	0.2609	0.2622	0.2422	
