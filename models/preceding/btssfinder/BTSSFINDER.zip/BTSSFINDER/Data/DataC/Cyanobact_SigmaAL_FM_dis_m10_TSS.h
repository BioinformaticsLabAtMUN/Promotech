Prom251_Cyanobact_SigmaAL.seq: Final -10/TSS distance FREQs Matrix for   8232 Proms (out of   8232)
10	Length of -10/TSS Distance Interval
3	12	MIN and MAX -10/TSS distances

0.0140	
0.0119	
0.0277	
0.0498	
0.5075	
0.2906	
0.0553	
0.0125	
0.0091	
0.0216	
