Prom251_Ecoli_Sigma38L.seq: Final -35/-10 distance FREQs Matrix for    100 Proms (out of    100)
8	Length of -35/-10 Distance Interval
15	22	MIN and MAX -35/-10 distances

0.1300	
0.1000	
0.1300	
0.1200	
0.0500	
0.1700	
0.1500	
0.1500	
