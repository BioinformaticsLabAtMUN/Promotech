Prom251_Cyanobact_SigmaFL.seq: Final -10/TSS distance FREQs Matrix for    586 Proms (out of    586)
9	Length of -10/TSS Distance Interval
4	12	MIN and MAX -10/TSS distances

0.0324	
0.2031	
0.0904	
0.0614	
0.1894	
0.1126	
0.1399	
0.1109	
0.0597	
