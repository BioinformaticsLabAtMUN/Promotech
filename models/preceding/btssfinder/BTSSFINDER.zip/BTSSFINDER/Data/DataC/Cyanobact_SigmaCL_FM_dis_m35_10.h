Cyanobact_SigmaCL.seq: Final -35/-10 distance FREQs Matrix for    303 Proms (out of    305)
8	Length of -35/-10 Distance Interval
15	22	MIN and MAX -35/-10 distances

0.1089	
0.1287	
0.1551	
0.1287	
0.0957	
0.1617	
0.1254	
0.0957	
