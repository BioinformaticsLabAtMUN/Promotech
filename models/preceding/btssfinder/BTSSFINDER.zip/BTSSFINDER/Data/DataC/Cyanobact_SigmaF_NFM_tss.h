Prom251_Cyanobact_SigmaFL.seq: Final TSS core-motif Matrix for    586 Proms (out of    586) ... Search region   195 : 202 ... Threshold =  -7.8100

0.8089	0.2150	0.2372	0.1297	0.2696	0.5990	
0.0666	0.1826	0.2833	0.0990	0.1297	0.1416	
0.0546	0.2986	0.1229	0.2167	0.3976	0.2065	
0.0700	0.3038	0.3567	0.5546	0.2031	0.0529	

Prom251_Cyanobact_SigmaFL.seq: Final TSS extended motif Matrix for    586 Proms (out of    586) ... Search region   195 : 202 ... Threshold =  -7.8100
9	Length of promoter element

0.8089	0.2150	0.2372	0.1297	0.2696	0.5990	0.2270	0.2355	0.2577	
0.0666	0.1826	0.2833	0.0990	0.1297	0.1416	0.2287	0.2577	0.2082	
0.0546	0.2986	0.1229	0.2167	0.3976	0.2065	0.2509	0.2423	0.2560	
0.0700	0.3038	0.3567	0.5546	0.2031	0.0529	0.2935	0.2645	0.2782	
