Prom251_Ecoli_Sigma38L.seq: Final UP/-35 distance FREQs Matrix for    100 Proms (out of    100)

  0.0100              0
  0.1700     >   0 and <=  10
  0.1100     >  10 and <=  20
  0.0800     >  20 and <=  30
  0.0700     >  30 and <=  40
  0.0400     >  40 and <=  50
  0.1000     >  50 and <=  60
  0.1000     >  60 and <=  70
  0.0600     >  70 and <=  80
  0.0500     >  80 and <=  90
  0.0200     >  90 and <= 100
  0.1900          > 100

Min UP/-35 distance:   0
Max UP/-35 distance: 129
