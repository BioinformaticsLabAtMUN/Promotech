Prom251_Ecoli_Sigma28L.seq: Final -10/TSS distance FREQs Matrix for    100 Proms (out of    100)
9	Length of -10/TSS Distance Interval
4	12	MIN and MAX -10/TSS distances

0.0100	
0.2200	
0.4500	
0.2500	
0.0100	
0.0400	
0.0100	
0.0000	
0.0100	
