Prom251_Ecoli_Sigma24L.seq: Final -10/TSS distance FREQs Matrix for    312 Proms (out of    312)
10	Length of -10/TSS Distance Interval
3	12	MIN and MAX -10/TSS distances

0.0032	
0.0128	
0.2917	
0.4199	
0.1571	
0.0064	
0.0288	
0.0449	
0.0192	
0.0160	
