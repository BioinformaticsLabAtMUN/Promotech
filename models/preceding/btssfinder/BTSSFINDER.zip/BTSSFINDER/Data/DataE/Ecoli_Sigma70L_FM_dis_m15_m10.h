Prom251_Ecoli_Sigma70L.seq: Final -15/-10 distance FREQs Matrix for   1331 Proms (out of   1344)
11	Length of -15/-10 Distance Interval
0	10	MIN and MAX -15/-10 distances

0.1563	
0.1029	
0.0939	
0.0864	
0.0699	
0.0631	
0.0789	
0.0909	
0.0744	
0.0894	
0.0939	
